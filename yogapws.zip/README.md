# YogaPWS
YogaPWS adalah sebuah web service portable yang bisa disambungkan ke setiap tabel yang ada pada database